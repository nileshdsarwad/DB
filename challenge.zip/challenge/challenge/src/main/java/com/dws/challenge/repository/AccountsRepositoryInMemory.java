package com.dws.challenge.repository;

import com.dws.challenge.domain.Account;
import com.dws.challenge.domain.Transaction;
import com.dws.challenge.exception.DuplicateAccountIdException;
import com.dws.challenge.service.EmailNotificationService;
import jakarta.validation.ValidationException;
import lombok.experimental.Accessors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class AccountsRepositoryInMemory implements AccountsRepository {
    @Autowired
    EmailNotificationService emailNotificationService;
    private final Map<String, Account> accounts = new ConcurrentHashMap<>();

    @Override
    public void createAccount(Account account) throws DuplicateAccountIdException {
        Account previousAccount = accounts.putIfAbsent(account.getAccountId(), account);
        if (previousAccount != null) {
            throw new DuplicateAccountIdException(
                    "Account id " + account.getAccountId() + " already exists!");
        }
    }

    @Override
    public Account getAccount(String accountId) {
        return accounts.get(accountId);
    }

    @Override
    public void clearAccounts() {
        accounts.clear();
    }

    @Override
    public synchronized String transferAmount(Transaction transaction) {

        Account accountReceiver = getAccount(transaction.getAccountToId());
        Account accountSender = getAccount(transaction.getAccountFromId());
        if (accountReceiver != null && accountSender != null) {
            if (checkBalance(accountSender.getBalance(), transaction.getAmount())) {
                BigDecimal remainingBalance = accountSender.getBalance().subtract(transaction.getAmount());
                accountSender.setBalance(remainingBalance);
                accountReceiver.setBalance(accountReceiver.getBalance().add(transaction.getAmount()));
                emailNotificationService.notifyAboutTransfer(accountReceiver,
                        transaction.getAmount() + " Amount has been credited and your current balance is " + accountReceiver.getBalance());
                emailNotificationService.notifyAboutTransfer(accountSender,
                        transaction.getAmount() + " Amount has been debited and your current balance is " + remainingBalance);
            } else {
                throw new ValidationException(" Insufficient balance ");
            }

        } else if (accountReceiver == null) {
            throw new ValidationException(" Receiver Account is not present");
        } else {
            throw new ValidationException(" Sender Account is not present");
        }

        return "Transaction successful";    


    }

    private boolean checkBalance(BigDecimal senderAmount, BigDecimal receiverAmount) {


        return (senderAmount.compareTo(receiverAmount) >= 0);


    }
}
